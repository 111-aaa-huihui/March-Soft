export default './lib/marked';
