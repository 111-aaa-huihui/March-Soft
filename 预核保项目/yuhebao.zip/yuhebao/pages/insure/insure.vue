<template>
	<view class="page">
		<view class="header" id="top-box">
			<view class="linedot">
				<view class="dot active"></view>
				<view class="line color-line"></view>
				<view class="dot active"></view>
				<view class="line"></view>
				<view class="dot"></view>
			</view>
			<view class="linetrip">
				<view class="trip active-text">添加疾病名称</view>
				<view class="trip active-text">完善核保问题</view>
				<view class="trip">核保意见书</view>
			</view>
		</view>
		<view class="content" :style="{height:swiperHeight}">
			<view class="introduce">
				<text class="title">完善核保问题</text>
				<view class="desc">更详细的疾病信息可以使核保结果更准确</view>
			</view>
			<view class="question-content" v-for="(sick, index) in sickList">
				<view class="sick-desc">
					请确认
					<text class="sick">{{ sick.name }}</text>
					相关问题
				</view>
				<view class="question-card">
					<view class="card-container" v-bind:style="{paddingLeft: index*20+20 + 'px' }" v-for="(question, index) in sick.questions">
						<view class="question">
							<text class="cuIcon-title">{{ question.name }}</text>
						</view>
						<radio-group class="answer" @change="RadioboxChange" :data-question="question.id" :data-sick="sick.disease_id">
							<view class="option" v-for="option in question.optionList">
								<radio color="#007AFF" style="transform:scale(0.8)" :value="option.id"></radio>
								<text>{{ option.content }}</text>
							</view>
						</radio-group>
					</view>
				</view>
			</view>
		</view>
		<view class="footer" id="foot-box">
			<view class="next" :class="isNext ? 'next-active' : '' " @click="next">下一步</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			answers: [
			],
			subjectIndex: 0, //跳转索引
			autoRadioNext: true, //判断题、单项题，自动移下一题
			swiperHeight: '800px', //
			title: '',
			delIds: [],
			isNext: false,
			questionList: [
				{"answer_list": [
						{
							name: '水是液体？',
							id: "A",
							optionList: [{ id: 'A', content: '对' }, { id: 'B', content: '错' }],
							answer: 'A',
							userAnswer: '',
							userFavor: false,
							description: '难到是固体不成？',
							issue_id: 2
						},
						{
							name: '电流分有？',
							id: "B",
							optionList: [{ id: 'A', content: '直流' }, { id: 'B', content: '交流' }, { id: 'C', content: '直流和交流' }],
							answer: 'C',
							userAnswer: '',
							userFavor: false,
							description: '科技学依据',
							issue_id: 3
						},
						{
							name: '酸菜鱼的味道？',
							id: "C",
							optionList: [{ id: 'A', content: '咸味' }, { id: 'B', content: '辣味' }, { id: 'C', content: '甜味' }, { id: 'D', content: '酸味' }],
							answer: 'A,B,D',
							userAnswer: '',
							userFavor: false,
							issue_id: 4,
							description: '你怎么想都行，要的就是这个味，答案只能选A,B,D'
						},
					]
				}
			],
			sickList: [
				{
					name: '甲状腺结节',
					disease_id: '1',
					questions: [
						{
							name: '水是液体？',
							id: 1,
							optionList: [{ id: 'A', content: '对' }, { id: 'B', content: '错' }],
							answer: 'A',
							userAnswer: '',
							userFavor: false,
							description: '难到是固体不成？'
						},
						{
							name: '电流分有？',
							id: 2,
							optionList: [{ id: 'A', content: '直流' }, { id: 'B', content: '交流' }, { id: 'C', content: '直流和交流' }],
							answer: 'C',
							userAnswer: '',
							userFavor: false,
							description: '科技学依据'
						},
						{
							name: '酸菜鱼的味道？',
							id: 3,
							optionList: [{ id: 'A', content: '咸味' }, { id: 'B', content: '辣味' }, { id: 'C', content: '甜味' }, { id: 'D', content: '酸味' }],
							answer: 'A,B,D',
							userAnswer: '',
							userFavor: false,
							description: '你怎么想都行，要的就是这个味，答案只能选A,B,D'
						}
					]
				},
				{
					name: '腰间盘突出',
					disease_id: '2',
					questions: [
						{
							name: '水是液体？',
							id: 5,
							optionList: [{ id: 'A', content: '对' }, { id: 'B', content: '错' }],
							answer: 'A',
							userAnswer: '',
							userFavor: false,
							description: '难到是固体不成？'
						},
						{
							name: '电流分有？',
							id: 6,
							optionList: [{ id: 'A', content: '直流' }, { id: 'B', content: '交流' }, { id: 'C', content: '直流和交流' }],
							answer: 'C',
							userAnswer: '',
							userFavor: false,
							description: '科技学依据'
						}
					]
				}
			]
		};
	},
	onReady() {
		var tempHeight = 800;
		var _me = this;
		uni.setNavigationBarTitle({
			 title: '添加疾病名称'
		})
		uni.getSystemInfo({
			//获取手机屏幕高度信息
			success: function(res) {
				// console.log(res.model);
				// console.log(res.pixelRatio);
				// console.log(res.windowWidth);
				// console.log(res.windowHeight);
				// //这里是手机屏幕高度
				// console.log(res.language);
				// console.log(res.version);
				// console.log(res.platform);
				tempHeight = res.windowHeight;
				console.log("屏幕可用高度 " + tempHeight);

				uni.createSelectorQuery().select("#top-box").fields({
					size: true,
					scrollOffset: true
				}, (data) => {
					tempHeight -= data.height;
					console.log("减掉顶部后的高度 " + tempHeight);
					uni.createSelectorQuery().select("#foot-box").fields({
						size: true,
						scrollOffset: true
					}, (data) => {
						tempHeight -= data.height;
						_me.swiperHeight = tempHeight + 'px';
						console.log("减掉底部后的高度 " + tempHeight);
						console.log("滑屏最后高度 " + _me.swiperHeight);
					}).exec();

				}).exec();
			}
		});
	},
	onLoad(option) {
		uni.setNavigationBarTitle({
			title: this.title
		});
		let ids = decodeURIComponent(option.ids);
		uni.request({
				url: 'https://dev.xxx.cn//api/yuhebao/disease/issue_list', //检查更新的服务器地址
				data: {
					disease_ids: ids
				},
				success: (res) => {
					console.log('success', res);
					if (res.statusCode == 200 && res.data) {
						this.sickList = res.data.data.list
						this.questionList = res.data.data.issue_list
						this.sickList.forEach(item => {
							item['questions'] = [this.getquestion(item.issue_id)]
						})
					}
				}
		})
	},
	watch:{
		answers:{
			deep: true,
			handler: function(cur, prev) {
				let answers = 0
				
				if (prev.length > 0) {
					this.sickList.forEach(sick => {
						answers += sick.questions.length;
					})
					if (answers == this.answers.length) {
						this.isNext = true
					} else {
						this.isNext = false
					}
				}
			}
		}
	},
	methods: {
		RadioboxChange(e) {
			//单选选中
			var sickId = e.currentTarget.dataset.sick;
			var questionId  = e.currentTarget.dataset.question;
			var answerId = e.detail.value;
			this.modifyAnswer(sickId,questionId,answerId)
			// this.addChild(sickId,questionId,answerId)
		},
		getquestion(id) {
			let result = {}
			if (this.questionList[id])
				result = this.questionList[id];

			return result;
		},
		
		getQuestionIds(id) {
			let ids = []
			if (this.questionList[id]) {
				let item = this.questionList[id]
				this.delIds.push(id)
				item.answer_list.forEach (item => {
					if (item.issue_id) {
						this.getQuestionIds(item.issue_id)
					}
				})
			}
		},
		// 修改问题答案
		modifyAnswer(sickId,questionId,answerId){
			if (this.answers.length === 0) {
				this.answers.push({sickId: sickId,questionId: questionId,answerId: answerId})
			} else {
				// this.getQuestionIds(questionId)
				let delIndexs = []
				this.answers.forEach((item,index) => {
					if (sickId == item.sickId &&  questionId === item.questionId) {
						delIndexs.push(index)
					}
				})
				delIndexs.forEach(item => {
					this.answers.splice(item,1)
				})
				this.answers.push({sickId: sickId,questionId: questionId,answerId: answerId})
			}
		},
		// 如果存在，添加当前疾病-问题-答案对应的子问题元素
		addChild(sickId,questionId,answerId) {
			let question = this.getquestion(questionId)
			debugger
			let childId = ''
			question.answer_list.forEach(item => {
				if (item.id == answerId) {
					childId = item.issue_id
				}
			})
			// 根据问题id获取并添加子问题
			if (childId) {
				let childQuestion = this.getquestion(childId)
				this.sickList.forEach(item => {
					if (sickId == item.disease_id) {
						item.questions.push(childQuestion)
					}
				})
			}
			//切换答案是删除上一次选择
			this.delLastChild(sickId, questionId, answerId)
			this.$forceUpdate();
		},
		delLastChild(sickId, questionId, answerId){
			let question = this.getquestion(questionId)
			let siblingId = '' // answerId的兄弟id
			question.answer_list.forEach(item => {
				if (item.id != answerId) {
					siblingId = item.issue_id
				}
			})
			// 根据问题id删除子问题
			if (siblingId) {
				let tempIndex = ''
				this.sickList.forEach(sickItem => {
					sickItem.questions.forEach((item,index)=> {
						if (siblingId == item.id) {
							tempIndex = index
						}
					})
					if (tempIndex!== ''){
						sickItem.questions.splice(tempIndex,1)
					}
				})
				
			}
		},
		next(){
			if (this.isNext) {
				let ids =[]
				this.answers.forEach(item => {
					ids.push(item.answerId)
				})
				let idStr = encodeURIComponent(ids.join(','))
				uni.navigateTo({
					url: "../result/result?ids="+idStr
				});
			} else {
				uni.showToast({
					title: '请完善核保问题'
				});
			}
			
		}
	}
};
</script>

<style lang="scss">
@import '../../components/animation.css';
page {
	background-color: #ffffff;
	height: 100%;
	overflow: hidden;
	position: relative;
}
.question-card {
	width: 90%;
	margin: 0 auto;
	background: #ffffff;
	box-shadow: 0 15px 500px 0 rgba(0, 0, 0, 0.08);
	border-radius: 6px;
	padding: 20upx 0;
}
.card-container {
	padding-bottom: 20upx;;
}
.question {
	font-size: 14px;
	color: #3f434e;
	text-align: left;
	padding-bottom: 38upx;
}
.answer {
	font-size: 14px;
	color: #3f434e;
	text-align: left;
	.option {
		display: inline-block;
		padding-right: 80upx;
		padding-bottom: 20upx;
		radio {
			margin-right: 8upx;
		}
	}
}
.sick-desc {
	font-size: 16px;
	color: #727e98;
	text-align: left;
	padding: 30upx 30upx;
	.sick {
		color: #3da0ff;
	}
}
.header {
	height: 138upx;
	text-align: center;
	background-color: #fafafa;
}
.linedot {
	display: flex;
	justify-content: center;
	align-items: center;
	padding-top: 36upx;
}
.linetrip {
	display: flex;
	justify-content: space-around;
	margin-top: 14upx;
}
.line {
	width: 30%;
	height: 1px;
	background: #ccc;
}
.color-line {
	background: #3da0ff;
}
.dot {
	width: 18upx;
	height: 18upx;
	border-radius: 50%;
	border: 1px solid #d3d6de;
	padding-left: 10upx;
	padding-top: 10upx;
}
.active {
	border: 1px solid #3da0ff;
}
.trip {
	font-size: 13px;
	color: #b3b4b9;
}
.active-text {
	color: #3da0ff;
}
.content {
	text-align: center;
	overflow: scroll;
	/* height: 400upx; */
}

.logo {
	height: 200upx;
	width: 200upx;
	margin-top: 200upx;
}

.introduce {
	padding: 36upx 30upx 0 30upx;
	text-align: left;
}
.title {
	font-size: 48upx;
	color: black;
	padding-bottom: 36upx;
}
.desc {
	font-size: 26upx;
	color: #727e98;
}
.footer {
	height: 120upx;
	width: 80%;
	margin: 0 auto;
	padding-top: 20upx;
	text-align: center;
}
.next {
	background-color: #d5dce3;
	color: white;
	border: none;
	border-radius: 46upx;
	font-size: 32upx;
	padding: 20upx 0;
}
.next-active {
	background: #3DA0FF;
	border-radius: 46upx;
	font-size: 16px;
	color: #FFFFFF;
	text-align: center;
}
</style>
