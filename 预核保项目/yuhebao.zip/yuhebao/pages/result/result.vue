<template>
	<view class="page">
		<view class="header">
			<view class="info">
				<view class="username">核保意见书</view>
				<navigator url="../index/index">
					<view class="repeat">重新核保</view>
				</navigator>
			</view>
		</view>
		<view class="box">
			<view class="result-title">
				<text class="selected">已选疾病</text>
					<text class="detail" @click="toDetail">疾病分析详情 ></text>
			</view>
			<view class="explain">
				本报告结论依据您所选疾病生成
			</view>
			<view class="result-items">
				<text class="result-item" v-for="item in selectedSicks">
					{{item.name}}
				</text>
			</view>
		</view>
		<uni-popup :show="middle" type="middle" mode="fixed" @hidePopup="hidePopup">
			<view class="cancel-icon" @click="hidePopup">
			</view>
			<view class="pop-dialog">
				<view class="card">
					<image src="../../static/avatar.png" mode="aspectFit"></image>
					<view class="profession">核保专家</view>
				</view>
				<view class="qrcode-container">
					<image class="qrcode" src="../../static/qrcode.png" mode="" @tap="previewImage"></image>
					<view class="trip">长按保存图片至相册</view>
					<view class="trip">使用微信扫一扫添加专家</view>
				</view>
			</view>
		</uni-popup>
		<view class="advice-box">
			<image class="advice-img" src="../../static/advice.png" mode="aspectFit"></image>
		</view>
		<uni-segmented-control :current="current" :values="items" @clickItem="onClickItem" style-type="button" active-color="#3DA0FF"></uni-segmented-control>
        <view class="content">
            <view v-show="current === 0">
				<view class="total-info">
					<text v-if="illness_list.length > 0">可投保产品({{illness_list.length}})</text>
					<text v-else>可投保产品</text>
				</view>
				<view class="warning-info">
					投保时，请注意健康告知中其他疾病的约束条件！
				</view>
				<view class="list" v-if="terms_list.length > 0">
					<view class="product" v-for="(product,index) in terms_list" @click="toProduct(product.url)" v-bind:class="{'noborder':index==illness_list.length-1}" :key="product.name" >
							<view class="name">{{product.name}}</view>
							<view class="point">
								<text>{{product.tag}}</text>
								<text class="price">{{product.price}} 元起</text>
							</view>
					</view>
				</view>
				<view class="empty" v-else>抱歉，暂无可投保产品</view>
				<view class="end">
						<text class="short-line"></text>
						<text class="end-trip">没有更多啦</text>
						<text class="short-line"></text>
				</view>
            </view>
            <view v-show="current === 1">
				<view class="total-info">
					<text v-if="medical_list.length > 0">可投保产品({{illness_list.length}})</text>
					<text v-else>可投保产品</text>
				</view>
				<view class="warning-info">
					投保时，请注意健康告知中其他疾病的约束条件！
				</view>
				<view class="list" v-if="medical_list.length > 0">
					<view class="product" v-for="(product,index) in medical_list" @click="toProduct(product.url)" v-bind:class="{'noborder':index==medical_list.length-1}" :key="product.name" >
							<view class="name">{{product.name}}</view>
							<view class="point">
								<text>{{product.tag}}</text>
								<text class="price">{{product.price}} 元起</text>
							</view>
					</view>
				</view>
				<view class="empty" v-else>抱歉，暂无可投保产品</view>
				<view class="end">
						<text class="short-line"></text>
						<text class="end-trip">没有更多啦</text>
						<text class="short-line"></text>
				</view>
			</view>
            <view v-show="current === 2">
				<view class="total-info">
					<text v-if="term_list.length > 0">可投保产品({{illness_list.length}})</text>
					<text v-else>可投保产品</text>
				</view>
				<view class="warning-info">
					投保时，请注意健康告知中其他疾病的约束条件！
				</view>
				<view class="list" v-if="term_list.length > 0">
					<view class="product" v-for="(product,index) in term_list"  v-bind:class="{'noborder':index==term_list.length-1}" :key="product.name" >
						<navigator :url="'../product/product?url=https://xxx.cn/product/view?cid=65'">
							<view class="name">{{product.name}}</view>
							<view class="point">
								<text>{{product.tag}}</text>
								<text class="price">60 元起</text>
							</view>
						</navigator>
					</view>
				</view>
				<view class="empty" v-else>抱歉，暂无可投保产品</view>
				<view class="end">
						<text class="short-line"></text>
						<text class="end-trip">没有更多啦</text>
						<text class="short-line"></text>
				</view>
			</view>
        </view>
		<view class="contact" @click="showPopup">
			咨询核保专家
		</view>
	</view>
</template>
<script>
	import list from '@/components/list.vue'
	import uniSegmentedControl from "@/components/uni-segmented-control/uni-segmented-control.vue"
	import uniPopup from "@/components/uni-popup/uni-popup.vue"
	export default {
		components: {
			uniPopup,
			list,
			uniSegmentedControl
		},
		data() {
			return {
				middle: false,
				items: ['重疾险&防癌险','医疗险','人寿险'],
				current: 0,
				answerIds: '',
				userinfo:{},
				selectedSicks:[],
				illness_list: [],
				medical_list: [],
				term_list: [],
				terms_list:[
					{name:'安联健康',url:'https://dev.xxx.cn/product/view?pid=38&client_type=3', tag: '健康险',price: 325},
					{name:'星悦',url:'https://dev.xxx.cn/product/view?pid=72', tag: '高性价比', price: 665},
					{name:'华贵大麦',url:'https://dev.xxx.cn/user',tag: '寿险', price: 665},
					{name:'小蜜蜂',url:'https://xxx.cn/product/view?cid=79',tag: '意外险', price: 2134},
					{name:'康惠保',url:'https://xxx.cn/product/view?cid=41',tag: '医疗险', price: 678},
					{name:'安享一生',url:'https://xxx.cn/product/view?cid=41',tag: '高性价比', price: 2345}
				],
				
			};
		},
		onShareAppMessage(res) {
			var me = this;
			return {
				title: '您的「核保意见书」待查看',
				path: '/pages/cover/cover',
				imageUrl: '../../static/shareResult.png'
			}
		},
		onLoad(option) {
			let anId = ''
			let history = option.history
			if (history) {
				uni.getStorageSync({
					key:'answerId',
					success(e){
						anId = e.data
						debugger
					}
				})
			} else {
				anId = option.ids
			}
			
			let ids = decodeURIComponent(anId);
			this.answerIds = option.ids
			uni.setStorage({
				key:'answerId',
				data: this.answerIds
			})
			uni.request({
					url: 'https://dev.xxx.cn//api/yuhebao/disease/opinion', //检查更新的服务器地址
					data: {
						answer_ids: ids
					},
					success: (res) => {
						console.log('success', res);
						if (res.statusCode == 200 && res.data) {
							this.selectedSicks = res.data.data.disease_list
							this.illness_list = res.data.data.illness_list
							this.medical_list = res.data.data.medical_list
							this.term_list = res.data.data.term_list
						}
					}
			})
		},
		// 页面滑动到底部触发
		onReachBottom() {
			
		},
		methods: {
			toDetail () {
				uni.navigateTo({
					url: "../detail/detail?ids="+ this.answerIds
				});
			},
			onClickItem(index) {
				if (this.current !== index) {
					this.current = index;
				}
			},
			//用户点击列表项
			toPage(product,index){
				uni.showToast({title: product.name});
			},
			hidePopup () {
				this.middle = false
			},
			showPopup () {
				this.middle = true
			},
			/*  图片预览方法
			*  此处注意的一点就是，调用 "wx.previewImage"时，第二个参数要求为数组形式
			*/ 
			previewImage(e) {
				var current = e.target.dataset.src;
				wx.previewImage({
				  current: current,
				  urls: ['https://xxx.cn/static/img/qcode.jpg']
				})
			 },
			toProduct (url) {
				let productUrl = encodeURIComponent(url);
				uni.navigateTo({
					url: "../product/product?url="+productUrl,
					success: res => {},
					fail: () => {},
					complete: () => {}
				});
			}
		}
	}
</script>

<style lang="scss">
page{background-color:#fff}
.header{
	// background-image: linear-gradient(180deg, #2AB2FE 0%, #4C9CFF 100%);
		// border-radius: 0 0 10px 10px;
	background-image: url('../../static/blueCard.png');
	background-size: cover;
	border-top: 1px solid #c5bebe;
	height: 300upx;
	padding:0 4%;
	display:flex;
	position: relative;
	align-items:center;

	.info{
		display:flex;flex-flow:wrap;padding-left:30upx;
		margin-bottom: 88upx;
		.username{
			width:100%;
			color:#fff;
			font-size:48upx}
		.repeat {
			color: #fff;
			font-size:28upx;
			margin-top: 14upx;
		}
		.repeat::after {
			content: '';
			z-index: 2;
			display: inline-block;
			width: 24upx;
			height: 24upx;
			margin-left: 10upx;
			background: url(../../static/arrow-right.png) no-repeat;
			background-size: contain;
		}
	}
	
	.setting{
		flex-shrink:0;width:6vw;height:6vw;
		image{width:100%;height:100%}
	}
}
.box{
	position: relative;
	width:78%;
	margin: -60upx auto;
	background-color:#fefefe;
	border-radius:24upx;
	box-shadow:0 0 20upx rgba(0,0,0,0.15);
	margin-bottom:40upx;
	padding: 52upx 36upx;
	.result-title{
		display:flex;
		align-items:center;
		justify-content:space-between;
		flex-flow:wrap;
		width:100%;
		color:#666666;
		font-size:26upx;
		margin-bottom: 6upx;
		.selected {
			font-size: 18px;
			color: #3F434E;
		}
		.detail {
			color: #2AB2FE
		}
	}
	.explain {
		font-size: 12px;
		color: #B3B4B9;
		margin-top: 6upx;
		margin-bottom: 30upx;
	}
	.result-items {
		display: flex;
		flex-wrap: wrap;
		.result-item {
			background-color: #F8F8F8;
			font-size: 14px;
			color: #727E98;
			background: #F8F8F8;
			border-radius: 22upx;
			padding: 6upx 16upx;
			margin-right: 16upx;
			margin-top: 16upx;
		}
	}
}
.advice-box {
	text-align: center;
	width: 100%;
	.advice-img {
		width: 330upx;
		height: 80upx;
		margin: 0 auto;
		will-change: all;
	}
}
.empty {
	color: #727E98;
	font-size: 32upx;
	text-align: center;
	margin-top: 80upx;
}
.total-info {
	font-size: 18px;
	color: #3F434E;
	margin-left: 7%;
	margin-bottom: 30upx;
	margin-top: 52upx;
}
.warning-info {
	font-size: 12px;
	color: #FA8C43;
	width: 90%;
	height: 48upx;
	line-height: 48upx;
	background: #FFF3D9;
	border-radius: 2px;
	text-align: center;
	margin: 0 auto;
}
.warning-info::before {
	content: '';
	z-index: 2;
	display: inline-block;
	width: 32upx;
	height: 32upx;
	background: url(../../static/warning.png) no-repeat;
	background-position-y: 10upx;
	background-size: contain;
}
.product {
	width: 90%;
	margin: 24upx auto;
	background: #FFFFFF;
	position: relative;
	box-shadow: 0 15px 500px 0 rgba(0,0,0,0.08);
	border-radius: 6px;
	font-family: PingFangSC-Regular;
	font-size: 16px;
	color: #3F434E;
	.name {
		font-size: 16px;
		color: #3F434E;
		padding-top: 24upx;
		margin-left: 24upx;
	}
	.point {
		font-size: 13px;
		color: #727E98;
		padding-top: 28upx;
		padding-bottom: 28upx;
		margin-left: 24upx;
		text {
			padding: 0 5px;
		}
	}
	.price {
		float: right;
		color: #F75F52;
		font-size: 16px;
	}
}
.list{
	width:100%;
	margin: 0 auto;
}
.end {
	display: flex;
	justify-content: center;
	align-items: center;
	height: 120upx;
	.short-line {
		height: 1px;
		width: 30%;
		background-color: #EBEBEB;
	}
	.end-trip {
		font-size: 12px;
		color: #B3B4B9;
		padding: 0 16upx;
		text-align: right;
	}
}
.cancel-icon {
	position: fixed;
    top: -50upx;
    right: 0;
    width: 40upx;
	height: 40upx;
	background: url(../../static/circleClose.png) no-repeat;
	background-size: contain;
}
.contact {
	position: fixed;
    bottom: 30%;
	width: 232upx;
	height: 64upx;
	text-align: center;
	line-height: 64upx;
    right: 0;
    background: #3DA0FF;
	border-radius: 100px 0 0 100px;
	transform: scaleX(1);
	background: #3DA0FF;
	font-size: 13px;
	color: #FFFFFF;
}
.contact::before {
	content: '';
	z-index: 2;
	display: inline-block;
	width: 40upx;
	height: 40upx;
	background: url(../../static/contact.png) no-repeat 0upx 10upx;/*兼容没测*/
	background-size: cover;
}
.contact-icon {
	width: 40upx;
	height: 40upx;
}
.tab-bar {
	border: 1px solid #3DA0FF;
	border-radius: 22px;
	width: 78%;
	height: 72upx;
	margin: 0 auto;
}
.pop-dialog {
	background-color: #2AB2FE;
	border-radius: 10upx;
	.card {
		width: 562upx;
		height: 252upx;
		text-align: center;
		background: url(../../static/bluebg.png) no-repeat;/*兼容没测*/
		background-size: cover;
		image {
			width: 108upx;
			height: 108upx;
			padding-top: 48upx;
		}
		.profession {
			font-size: 14px;
			color: white;
			padding-top: 14upx;
		}
	}
	.qrcode-container {
		background-color: white;
		margin: 0 auto;
		width: 100%;
		height: 514upx;
		.trip {
			font-size: 13px;
			color: #B3B4B9;
			text-align: center;
			padding-top: 18upx;
		}
	}
	.qrcode {
		width: 300upx;
		height: 300upx;
		margin: 0 auto;
		display: block;
		padding-top: 60upx;
	}
}
</style>
