<template>
    <view class="page">
        <view class="black-card">
        </view>
        <view class="search-content">
			<view class="search-header">
				<view class="search-title">
					<text>搜索或选择疾病</text>
					<text>X</text>
				</view>
				<view class='searchbox'>
					<image src='/static/icon-search.png' class='search-icon'></image>
					<input class="search-input" focus confirm-type="search" placeholder="疾病名称/诊断证明书的病症名称" />
				</view>
			</view>
			<list v-if="searchResult.length !== 0"></list>
			<multi-select v-else :sicks="healthInfos" @selected="selectSick"></multi-select>
        </view>
    </view>
</template>

<script>
	import list from '@/components/list.vue'
	import multiSelect from '@/components/multi-select.vue'
	export default {
		components: {list,multiSelect},
        data() {
            return {
                providerList: [],
                hasProvider: false,
				searchResult: [],
				healthInfos: [
				{
					id: 1, level: 0, healthNo: "D101604", healthDescribe: "甲状腺疾病",
					list: [
						{
							id: 2, level: 1, healthNo: "D101608", healthDescribe: "甲状腺",parent_id : 1,
							list: [
								{id: 311, parent_id: 2, level: 2, healthNo: "D101612", healthDescribe: "甲状腺功能亢进"},
								{id: 312, parent_id: 2, level: 2, healthNo: "D101616", healthDescribe: "甲状腺功能减退"},
								{id: 314, parent_id: 2, level: 2, healthNo: "D101620", healthDescribe: "甲状腺肿"},
								{id: 315, parent_id: 2, level: 2, healthNo: "D101624", healthDescribe: "甲状腺结节/甲状腺良性肿瘤"},
								{id: 313, parent_id: 2, level: 2, healthNo: "D101627", healthDescribe: "甲状腺炎"},
								{id: 316, parent_id: 2, level: 2, healthNo: "D101632", healthDescribe: "甲状腺癌"}
							]
						},
						{
							id: 61, parent_id : 1, level: 1, healthNo: "D101637", healthDescribe: "甲状旁腺",
							list: [
								{id: 73, parent_id: 61, level: 2, healthNo: "D101641", healthDescribe: "甲状旁腺功能亢进"},
								{id: 83, parent_id: 61, level: 2, healthNo: "D101642", healthDescribe: "甲状旁腺功能减退"}
							]
						},
						{id: 5, parent_id : 1, level: 1, healthNo: "D101643", healthDescribe: "甲状腺其他疾病"}
					]
				},
				{
					id: 11, level: 0, healthNo: "D101606", healthDescribe: "心血管疾病",
					list: [
					 {
						 id: 12, parent_id : 11,level: 1, healthNo: "D101611", healthDescribe: "血压异常",
						 healthInfos: [
							{id: 183, parent_id : 12, level: 2, healthNo: "D101613", healthDescribe: "原发性高血压或血压升高（收缩压达到140mmHg或舒张压达到90mmHg）"},
							{id: 193, parent_id : 12, level: 2, healthNo: "D101617", healthDescribe: "妊娠高血压"},
							{id: 103, parent_id : 12, level: 2, healthNo: "D101621", healthDescribe: "低血压（收缩压低于100mmHg或舒张压低于60mmHg）（男性客户选择）"},
							{id: 173, parent_id : 12, level: 2, healthNo: "D101625", healthDescribe: "低血压（收缩压低于90mmHg或舒张压低于60mmHg）（女性客户选择）"}
						 ]
					 },
					 { 
						 id: 14, parent_id : 11, level: 1, healthNo: "D101629", healthDescribe: "心律失常",
						 healthInfos: [
							{id: 15, parent_id : 14, level: 2, healthNo: "D101631", healthDescribe: "窦性心动过速（窦速）"},
							{id: 15, parent_id : 14, level: 2, healthNo: "D101636", healthDescribe: "窦性心动过缓（窦缓）"},
							{id: 15, parent_id : 14, level: 2, healthNo: "D101638", healthDescribe: "房性心动过速（房速）、室上性心动过速（室上速）"},
							{id: 15, parent_id : 14, level: 2, healthNo: "D101645", healthDescribe: "室性心动过速（室速）"},
							{id: 15, parent_id : 14, level: 2, healthNo: "D101650", healthDescribe: "室性期前收缩（室性早搏、室早）"},
							{id: 15, parent_id : 14, level: 2, healthNo: "D101656", healthDescribe: "预激综合征"},
							{id: 15, parent_id : 14, level: 2, healthNo: "D101661", healthDescribe: "房室传导阻滞"},
						 ]
					 },
					 {id: 16, parent_id : 11, level: 1, healthNo: "D101701", healthDescribe: "先天性心脏病"},
					 {id: 17, parent_id : 11, level: 1, healthNo: "D101714", healthDescribe: "心脏疾病"},
					 {id: 18, parent_id : 11, level: 1, healthNo: "D101782", healthDescribe: "心包"},
					 {id: 19, parent_id : 11, level: 1, healthNo: "D101796", healthDescribe: "血管"},
					 {id: 20, parent_id : 11, level: 1, healthNo: "D101804", healthDescribe: "其他心血管疾病"},
					]
				},
				{id: 21, level: 0, healthNo: "D101605", healthDescribe: "代谢异常"},
				{id: 22, level: 0, healthNo: "D101607", healthDescribe: "呼吸系统疾病"},
				{id: 23, level: 0, healthNo: "D101647", healthDescribe: "消化系统疾病"},
				{id: 34, level: 0, healthNo: "D101648", healthDescribe: "泌尿系统疾病"},
				{id: 35, level: 0, healthNo: "D101747", healthDescribe: "神经及精神系统疾病"},
				{id: 36, level: 0, healthNo: "D101761", healthDescribe: "血液系统疾病"},
				{id: 37, level: 0, healthNo: "D101820", healthDescribe: "乳腺、妇科、男性生殖"},
				{id: 38, level: 0, healthNo: "D101851", healthDescribe: "眼、耳、口、鼻"},
				{id: 39, level: 0, healthNo: "D101885", healthDescribe: "皮肤、肌肉、骨骼及关节"},
				{id: 40, level: 0, healthNo: "D101926", healthDescribe: "其他"},
				],
            }
        },
		methods: {
			selectSick(values) {
				// debugger	
			}
		},
        onReady() {
            // this.initPosition();
            // this.initProvider();
        }
    }
</script>

<style>
	.page {
		background-color: #000000;
		height: 100%;
	}
    .black-card {
        background-color: #000000;
		height: 164upx;
    }
	
    .search-content {
        border-radius: 12upx 12upx 0 0;
		background-color: #FFFFFF;
    }
	.search-title {
		display: flex;
		justify-content: space-between;
		color: #3F434E;
	}
	
	.search-header {
		height: 220upx;
		padding: 42upx 30upx;
		text-align: center;
	}
	.search-input {
		flex: 1;
		font-size: 14px;
		color: #B3B4B9;
	}
	.searchbox {
		border-radius: 40upx;
		background-color: #F7F7F7;
		font-size: 28upx;
		padding: 16upx 24upx;
		text-align: left;
		margin-top: 46upx;
		display: flex;
		align-items: center;
	}
	.search-icon {
		width: 32upx;
		height: 32upx;
		padding-right: 16upx;
	}
</style>
