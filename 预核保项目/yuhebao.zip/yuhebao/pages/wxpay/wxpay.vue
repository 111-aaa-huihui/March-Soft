<template >
	<view class = "page">
	</view>
</template>

<script>
	export default {
		data() {
			return {
				payTempcode: '',
				orderId: '',
				payParam: {},
				user_coupon_id: ''
			}
		},
		methods: {
			getTempcode: function() {
				uni.login({
					success: res => {
						debugger
						this.payTempcode = res.code
						let cookieTemp = uni.getStorageSync("cookie");
						let orderId = uni.getStorageSync("orderId");
						let user_coupon_id = uni.getStorageSync('user_coupon_id')
						console.log("333333", cookieTemp, orderId, user_coupon_id);
						if (cookieTemp != '') {
							this.getPayinfo();
						} else { //如果小程序被删除了 获取不到登录存储的cookie
							let transUrl = 'https://dev.xxx.cn/mini_program_login?id=' + orderId + '&coupon_id=' + user_coupon_id;
							uni.navigateTo({
								url: "../product/product?url=" + encodeURIComponent(transUrl)
							})
						}

					}
				})
			},
			// 换取支付参数
			getPayinfo: function() {
				var self = this;
				uni.request({
						url: 'https://dev.xxx.cn/api/user/order/wx_pay', //仅为示例，并非真实接口地址。
						method: 'POST',
						data: {
								'code': self.payTempcode,
								'id': uni.getStorageSync('orderId'),
								'user_coupon_id': uni.getStorageSync('user_coupon_id'),
								'appid': 'wxfd7db12131e311db'
						},
						header: {
								'content-type': 'application/x-www-form-urlencoded', 
								'cookie': uni.getStorageSync("cookie")
						},
						success: (res) => {
								console.log('success'+res.data)
								res = res.data;
								if (res.code == 1) {
									self.payParam = res.data
									uni.requestPayment({
										'timeStamp': self.payParam.timeStamp, //为字符串，否则报错
										'nonceStr': self.payParam.nonceStr,
										'package': self.payParam.package,
										'signType': 'MD5',
										'paySign': self.data.payParam.paySign,
										'success': function(res) {
											let transUrl = "https://dev.xxx.cn/user/order/result?id=" + uni.getStorageSync('orderId');
											uni.navigateTo({
												url: "../product/product?url="+ encodeURIComponent(transUrl)
											})
										},
										'fail': function(res) {
											let transUrl = "https://dev.xxx.cn/user/order/result?id=" + uni.getStorageSync('orderId') +
												"&from=compareMinipro";
											uni.navigateTo({
												url: "../product/product?url="+ encodeURIComponent(transUrl)
											})
										}
									})
								} else {
									uni.showModal({
										title: '请求发送失败',
										content: res.message,
										showCancel: false,
										confirmText: '确定'
									});
								}
						},
						fail(res) {
							console.log('fail'+res)
							uni.showModal({
								title: '请求发送失败',
								content: res.message,
								showCancel: false,
								confirmText: '确定'
							});
						}
				});
			}
		},
		onLoad: function(options) {
			console.log(options)
			//如果是重新登录过的
			if (options.CM_S) {
				let userCookie = options.CM_S;
				uni.setStorageSync('cookie', 'CM_S=' + userCookie);
			}
			this.orderId = options.orderId;
			this.user_coupon_id = options.coupon;
			uni.setStorageSync('orderId', options.orderId);
			uni.setStorageSync('user_coupon_id', options.coupon)
			this.getTempcode();
		}
	} 
</script>

<style>
.page {
		background-color: #000000;
		height: 100%;
	}
</style>
