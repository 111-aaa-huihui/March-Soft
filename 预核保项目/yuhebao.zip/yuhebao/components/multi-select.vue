<template>
	<view>
		<view class="sel-sick-container">
			<view class="sel-sick-result">
				<view class="items">
					<text class="item" :class="item.name ? '' : 'active'" @tap="" @click="switchLevel(item)" v-for="item in sickInfo">{{ item.name || '请选择' }}</text>
				</view>
			</view>
			<view class="sick-content">
				<view class="sick" v-for="item in sickList" @click="setValue(item)">{{ item.name }}</view>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	name: 'multi-select',
	props: {
		sicks: {
			type: [Array],
			default: []
		}
	},
	data() {
		return {
			curSelecting: 0,
			sickList: this.sicks,
			curSick: {},
			sickInfo: [
				{
					name: '',
					id: '',
					parent_id: '',
					level: ''
				}
			]
		};
	},
	computed: {
		options() {
			return this.sickList;
		}
	},
	watch: {
		curSelecting: function(cur, prev) {
		},
		'sicks': function(newData,oldData){
			this.sickList = newData;
		}
	},
	methods: {
		//切换疾病等级
		switchLevel(item) {
			this.curSelecting = item.level;
			this.sickInfo.splice(this.curSelecting);
			if (item.level == 0) {
				this.sickInfo = [
					{
						name: '',
						id: '',
						level: ''
					}
				];
				this.sickList = this.sicks;
			} else {
				this.sickInfo.push({
					name: '',
					id: '',
					level: ''
				});
				this.sickList = this.curSick.list;
			}
		},
		//
		getList(list, id) {
			if (list && list.length == 0) return [];
			list.forEach(item => {
				if (item.id == id) {
					return item.list;
				} else {
					return this.getList(item.list);
				}
			});
		},
		// 选择疾病
		setValue(item) {
			if (item.level == 0) {
				this.curSick = item;
			}
			this.sickInfo[item.level].name = item.name;
			this.sickInfo[item.level].id = item.id;
			this.sickInfo[item.level].parent_id = item.parent_id;
			this.sickInfo[item.level].level = item.level;
			//添加选择tab
			if (item.list && item.list.length > 0) {
				this.sickList = item.list;
				this.sickInfo.push({ name: '', id: '' });
				this.curSelecting = item.level;
			} else {
				this.save();
				this.sickInfo = [
					{
						name: '',
						id: '',
						level: ''
					}
				];
				this.sickList = this.sicks
			}
		},
		save() {
			this.$emit('selected', this.sickInfo[this.sickInfo.length-1]);
		},
		close() {},
		fetchData() {}
	},
	created() {
		this.fetchData();
	}
};
</script>

<style lang="less">
.sel-sick-container {
	padding: 0;
	width: 100%;
	text-align: left;
	font-size: 14px;
	color: #3f434e;
	.sel-sick-result {
		border-bottom: 1px solid #edeef1;
		.items {
			display: flex;
			.item {
				padding: 20upx;
				color: #3f434e;
				&.active {
					color: #3da0ff;
					border-bottom: 1px solid #3da0ff;
				}
			}
		}
	}

	.sick-content {
		padding: 20upx 40upx;
		max-height: 600upx;
		overflow: scroll;
		.sick {
			color: #3f434e;
			line-height: 80upx;
			border-bottom: 1px solid #edeef1;
			&.active {
				color: bisque;
			}
		}
	}
}
</style>
