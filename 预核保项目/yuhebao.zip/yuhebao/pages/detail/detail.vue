<template>
	<view class="page">
		<view class="result-items">
			<text class="result-item" v-for="item in analyseList" :class="item.id == curIndex ? 'active' : ''" @click="setIndex(item.id)" >
				{{item.name}}
			</text>
		</view>
		<view class="content" v-for="item in analyseList" v-if="item.id == curIndex">
			<view class="desc">
				<view class="title">疾病描述</view>
				<view class="desc-detail">{{item.description}}</view>
			</view>
			<view class="line"></view>
			<view class="intro">核保说明</view>
			<view class="desc">
				<view class="sick-name">重疾险&防癌险</view>
				<view class="desc-detail">{{item.illness_suggest}}</view>
			</view>
			<view class="desc">
				<view class="sick-name">医疗险</view>
				<view class="desc-detail">{{item.medical_suggest}}</view>
			</view>
			<view class="desc">
				<view class="sick-name">人寿险</view>
				<view class="desc-detail">{{item.term_suggest}}</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				curIndex: 1,
				analyseList:[
					{id: 1, name: 'xxx疾病分析', description: "疾病分析状况", illness_suggest: "重疾险&防癌险建议",medical_suggest: '医疗险推荐和建议',term_suggest: "人寿险推荐和建议"}
				],
				title: '请添加疾病名称'
			}
		},
		onLoad(option) {
			let me = this
			let ids = decodeURIComponent(option.ids);
			uni.request({
					url: 'https://dev.xxx.cn/api/yuhebao/disease/analysis', //检查更新的服务器地址
					data: {
						answer_ids: '31,10'
					},
					success: (res) => {
						console.log('success', res);
						if (res.statusCode == 200 && res.data) {
							me.analyseList = res.data.data
							let ad = me.analyseList;
							debugger
							me.curIndex = me.analyseList[0].id
						}
					}
			})
		},
		methods: {
			setIndex(index){
				this.curIndex = index
			}
		}
	}
</script>

<style>
	page{
		height: 100%;
		position: relative;
		padding: 30upx 30upx;
	}
	.result-items {
		height: 96upx;
		overflow: scroll;
	}
	.result-item {
		background-color: #F8F8F8;
		font-size: 14px;
		color: #3F434E;
		border-radius: 28upx;
		padding: 8upx 16upx;
		margin-right: 16upx;
		margin-bottom: 16upx;
		word-break: keep-all;
	}
	.active {
		background: #3DA0FF;
		color: #FFFFFF;
	}
	.line {
		background: rgba(234,236,243,0.60);
		height: 1px;
		margin: 54upx 0;
	}
	.trip {
		font-size: 13px;
		color: #B3B4B9;
	}
	.content {
		text-align: center;
		/* height: 400upx; */
	}

	.desc {
		text-align: left;
		margin-top: 34upx;
	}
	.title {
		font-size: 32upx;
		color: #3F434E;
		padding-bottom: 36upx;
	}
	.title::before {
		content: '';
		z-index: 2;
		display: inline-block;
		width: 32upx;
		height: 32upx;
		background: url(../../static/desc.png) no-repeat top left /32upx 32upx;/*兼容没测*/
		background-size: contain;
	}
	.intro {
		font-size: 32upx;
		color: #3F434E;
		text-align: left;
	}
	.intro::before {
		content: '';
		z-index: 2;
		display: inline-block;
		width: 32upx;
		height: 32upx;
		background: url(../../static/intro.png) no-repeat top left /32upx 32upx;/*兼容没测*/
		background-size: contain;
	}
	.sick-name {
		font-family: PingFangSC-Regular;
		font-size: 14px;
		color: #3F434E;
		line-height: 24px;
	}
	.sick-name::before{
		content: '';
		background-color: #3DA0FF;
		border-radius: 1px;
		display: inline-block;
		margin-right: 16upx;
		width: 2px;
		height: 8px;
	}
	.desc-detail {
		font-size: 28upx;
		color: #727E98;
		margin-top: 10upx;
	}
</style>
