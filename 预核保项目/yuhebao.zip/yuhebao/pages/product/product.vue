<template>
	<view>
		<!-- <text>{{url}}</text> -->
		<block v-if="url">
			<web-view :src="url"></web-view>
		</block>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				url: '',
				loaded: false,
				webviewStyles: {
                    progress: {
                        color: '#FF3333'
                    }
                }
			}
		},
		methods:{
		
		},
		onLoad: function (option) {
			let productUrl = decodeURIComponent(option.url)
			this.url = productUrl
		}
	}
</script>

<style>

</style>
