<template>
	<view>
		<view class="container">
			<image src="../../static/cover.png" mode="widthFix" ></image>
		<view class="intro">人工智能大数据算法，一分钟完成疾病核保问卷</view>
		<view class="intro">给您安心便捷的投保体验</view>
		<view class="btn-container" v-if="isInsure">
			<navigator class="insure-last" url="../result/result?history=1">
				<view>上次核保结果</view>
			</navigator>
			<navigator class="insure-again" url="../index/index">
				<view >再次核保</view>
			</navigator>
		</view>
		<view class="btn-container" v-else>
			<navigator url="../index/index">
				<view class="insure-btn">立即核保</view>
			</navigator>
		</view>
		<view class="announce">免责声明：核保结果今仅供参考，不作为保险公司最终结论</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isInsure: false
			}
		},
		onLoad() {
			let me = this
			uni.getStorageSync({  
				key: "answerId",  
				success: (res) => {  
					if (res.data)
					me.isInsure = true
				}  
			})
		},
		onShareAppMessage(res) {
			var me = this;
			return {
				title: '身体有异常，不知道能买哪些保险？快来问问我吧',
				path: '/pages/cover/cover',
				imageUrl: '../../static/shareCover.png'
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	.container {
		width: 100%;
		height: 100%;
		background-size: 100% auto ;
		padding: 0;
	}
	image {
		width: 100%;
		margin: 0 auto;
	}
	.intro {
		font-family: PingFangSC-Regular;
		font-size: 13px;
		color: #3DA0FF;
		letter-spacing: 0;
		text-align: center;
		line-height: 30px;
	}
	.btn-container {
		text-align: center;
	}
	.insure-btn {
		margin: 20upx auto;
		background: #3DA0FF;
		border-radius: 23px;
		font-family: PingFangSC-Regular;
		font-size: 16px;
		text-align: center;
		width: 80%;
		height: 92upx;
		line-height: 92upx;
		color: #FFFFFF;
	}
	.insure-last {
		margin: 20upx auto;
		display: inline-block;
		border: 1px solid #3DA0FF;
		border-radius: 23px;
		font-family: PingFangSC-Regular;
		font-size: 16px;
		text-align: center;
		width: 40%;
		height: 92upx;
		line-height: 92upx;
		color: #3DA0FF;
	}
	.insure-again {
		margin: 20upx auto;
		display: inline-block;
		background: #3DA0FF;
		border-radius: 23px;
		font-family: PingFangSC-Regular;
		font-size: 16px;
		text-align: center;
		width: 40%;
		height: 92upx;
		line-height: 92upx;
		color: #FFFFFF;
		margin-left: 10px;
	}
	.announce {
		font-family: PingFangSC-Regular;
		font-size: 10px;
		color: #727E98;
		letter-spacing: 0;
		text-align: center;
		line-height: 30px;
	}
	
</style>
