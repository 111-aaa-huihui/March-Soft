<template>
	<view class="page">
		<view class="header">
			<view class="linedot">
				<view class="dot finished"></view>
				<view class="line"></view>
				<view class="dot"></view>
				<view class="line"></view>
				<view class="dot"></view>
			</view>
			<view class="linetrip">
				<view class="trip active-text">添加疾病名称</view>
				<view class="trip">完善核保问题</view>
				<view class="trip">核保意见书</view>
			</view>
		</view>
		<uni-popup :show="isShow" type="bottom" position="bottom" mode="fixed" @hidePopup="hidePopup">
			<view class="pop-container">
				<!-- <view class="black-card"></view> -->
				<view class="search-content">
					<view class="search-header">
						<view class="search-title">
							<text>搜索或选择疾病</text>
							<image @click="hidePopup" src="../../static/cancel.png" class="close-icon" mode="scaleToFill"></image>
							<!-- <icon type="clear" size="26" /> -->
						</view>
						<view class="searchbox">
							<image src="/static/icon-search.png" class="search-icon"></image>
							<input class="search-input" focus confirm-type="search" @confirm="searchSick" placeholder="疾病名称/诊断证明书的病症名称" />
						</view>
					</view>
					<list v-if="searchResult.length !== 0" :sicks="searchResult" :value="keyWords" @selected="selectSick"></list>
					<multi-select v-else :sicks="healthInfos" @selected="selectSick"></multi-select>
				</view>
			</view>
		</uni-popup>
		<view class="content">
			<view class="introduce">
				<view class="title">{{ title }}</view>
				<view class="desc">请添加您有诊断记录的疾病，大数据帮您分析疾病情况，制定详细的核保意见书</view>
			</view>
			<view class="btn-area">
				<!-- <navigator url="../search/search" hover-class="navigator-hover"> -->
				<view class="addbtn" @click="show">
					<text class="plus">+</text>
					添加疾病
				</view>
				<!-- </navigator> -->

				<view class="sick-list">
					<view class="select-sick"  v-for="sick in sickList">
						<text class="sick-name">{{ sick.name }}</text>
						<view class="cancel-icon" @click="delSick(sick.id)"></view>
					</view>
				</view>
			</view>
		</view>
		<view class="footer">
			<view class="next" :class="isNext ? 'next-active' : '' " @click="next">下一步</view>
		</view>
	</view>
</template>

<script>
import uniPopup from '@/components/uni-popup/uni-popup.vue';
import list from '@/components/list.vue';
import multiSelect from '@/components/multi-select.vue';
export default {
	components: {
		uniPopup,
		list,
		multiSelect
	},
	data() {
		return {
			isShow: false,
			title: '请添加疾病名称',
			sickList: [],
			isNext: false,
			searchResult: [],
			page: 1,
			totalPages: 1,
			keyWords: '',
			healthInfos: [],
			allSick: [
				{'name': "甲状腺结节", 'id': 1},
				{'name': "骨折",'id': 2},
				{'name': "骨质增生",'id': 3},
				{'name': "高血压", 'id': 4},
				{'name': "高血脂", 'id': 5},
				{'name': "关节炎", 'id': 6},
			]
		};
		
	},
	onLaunch: function() {
		console.log('App Launch')
	},
	onLoad() {
		uni.request({
				url: 'https://dev.xxx.cn/api/yuhebao/disease/list', //检查更新的服务器地址
				data: {
				},
				success: (res) => {
					console.log('success', res);
					if (res.statusCode == 200 && res.data) {
						this.allSick = res.data.data.list
						this.healthInfos = res.data.data.tree_list
					}
				}
		})
	},
	watch:{
		"sickList"(cur) {
			if (cur.length > 0) {
				this.isNext = true
			} else {
				this.isNext = false
			}
		}
	},
	methods: {
		show() {
			this.isShow = true;
			this.searchResult = []
		},
		hidePopup() {
			this.isShow = false;
		},
		selectSick(values) {
			if (this.sickList.length >= 3) {
				uni.showToast({
					title: '最多选择三项疾病',
					icon: 'none'
				});
				return
			} else {
				if(this.isSelect(values)) {
					this.sickList.push(values);
					this.hidePopup()
				}
			}
		},
		isSelect(value){
			let status = true
			this.sickList.forEach(item =>{
				if (item.id == value.id) {
					status = false;
					uni.showToast({
						title: '该疾病已选择',
						icon: 'none'
					});
				}
			})
			return status;
		},
		delSick (id) {
			this.sickList.forEach((item,index) =>{
				if (item.id == id) {
					this.sickList.splice(index, 1)
					return
				}
			})
		},
		searchSick(e){
			var me = this;
			var val = e.detail.value;
			me.keyWords = val;
			var temp = [];
			this.allSick.forEach(item =>{
				var name = item.name;
				me.sickList.forEach(sick => {
					if (sick.name == name) {
						item['active'] = true
					}
				})
				if (name.indexOf(val) != -1){
					temp.push(item);
				}
			});
			me.searchResult = temp
		},
		next(){
			if (this.isNext) {
				let ids =[]
				this.sickList.forEach(item => {
					ids.push(item.id)
				})
				let idStr = encodeURIComponent(ids.join(','))
				uni.navigateTo({
					url: "../insure/insure?ids="+idStr
				});
			} else {
				uni.showToast({
					title: '请先添加疾病',
					icon: 'none'
				});
			}
			
		}
	}
};
</script>

<style>
@import url('../../components/search.css');
page {
	height: 100%;
	position: relative;
}
.header {
	height: 138upx;
	text-align: center;
	background-color: #fafafa;
}
.linedot {
	display: flex;
	justify-content: center;
	align-items: center;
	padding-top: 36upx;
}
.linetrip {
	display: flex;
	justify-content: space-around;
	margin-top: 14upx;
}
.line {
	width: 30%;
	height: 1px;
	background: #ccc;
	/* position: absolute;
		top: 0;
		left: 15px; */
}
.dot {
	width: 18upx;
	height: 18upx;
	border-radius: 50%;
	border: 1px solid #d3d6de;
	padding-left: 10upx;
	padding-top: 10upx;
}
.finished {
	border: 1px solid #3da0ff;
}
.trip {
	font-size: 13px;
	color: #b3b4b9;
}
.active-text {
	color: #3da0ff;
}
.content {
	text-align: center;
	/* height: 400upx; */
}

.logo {
	height: 200upx;
	width: 200upx;
	margin-top: 200upx;
}

.introduce {
	padding: 36upx 30upx;
	text-align: left;
}
.title {
	font-size: 48upx;
	color: black;
	padding-bottom: 36upx;
}
.desc {
	font-size: 26upx;
	color: #727e98;
}
.addbtn {
	border: 6upx dashed rgba(61, 160, 255, 0.6);
	border-radius: 4upx;
	padding: 26upx 0;
	margin: 54upx 30upx;
	font-size: 32upx;
	color: #3da0ff;
}
.plus {
	font-size: 44upx;
}
.sick-list {
	display: flex;
	flex-wrap: wrap;
	justify-content: left;
	padding: 0 36upx;
}
.sick-name {
	text-overflow: ellipsis;
	white-space: nowrap;
	font-size: 14px;
	color: #ffffff;
}
.select-sick {
	border-radius: 2px;
	opacity: 0.8;
	padding: 8upx 20upx;
	margin-right: 20upx;
	margin-top: 20upx;
	background: #3da0ff;
}
.cancel-icon {
	width: 24upx;
	height: 24upx;
	background-image: url('../../static/close.png');
	background-size: contain;
    background-repeat: no-repeat;
    display: inline-block;
	margin-left: 5px;
}
.close-icon {
	width: 10px;
	height: 10px;
	padding-left: 5px;
}
.footer {
	position: absolute;
	display: block;
	height: 138upx;
	width: 80%;
	margin: 54upx 76upx;
	text-align: center;
	bottom: 0upx;
}
.next {
	background-color: #d5dce3;
	color: white;
	border: none;
	border-radius: 46upx;
	font-size: 32upx;
	padding: 24upx 0;
}
.next-active {
	background: #3DA0FF;
	border-radius: 46upx;
	font-size: 16px;
	color: #FFFFFF;
	text-align: center;
}
</style>
